﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMTipoDocumentoVenta
    {
        public int IdTipoDocumentoVenta { get; set; }

        public string? Descripcion { get; set; }
    }
}
