﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMCambiarClave
    {
        public string? ClaveNueva{ get; set; }
        public string? ClaveActual { get; set; }
    }
}
