﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMProductosSemana
    {
        public string? Producto { get; set; }         
        public int Cantidad { get; set; }
    }
}
